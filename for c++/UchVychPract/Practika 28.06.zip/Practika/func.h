#define __LIST_H__
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string.h>
#pragma warning(disable:4996)
#include <string>
#include <list>
using namespace std;
struct Info
{
    string name_product;
    int material_cost;
    int prod_volume;
    int fin_cost;
};

class Product
{
    list<Info> list_products;
    int salary;
    int rent;
    int other_costs;
    int size;

public:
    Product();
    Product(Info tproduct);
    Product(list<Info> tproduct);
    Product(Product& tproduct);
    ~Product();
    int TotalVolume();
    int ProdCost();
    void Cost();
    friend ostream& operator<< (ostream& out, Product& t);
    friend istream& operator>> (istream& in, Product& t);
};

Product::Product()
{
    size = 0;
}

Product::Product(Info tproduct)
{
    list_products.push_back(tproduct);
    size = 1;
}

Product::Product(list<Info> tproduct)
{
    for(auto i = tproduct.begin(); i!=tproduct.end(); i++)
    {
        list_products.push_back(*i);
        size++;
    }
}

Product::Product(Product& tproduct)
{
    for(auto i = tproduct.list_products.begin(); i!=tproduct.list_products.end(); i++)
    {
        list_products.push_back(*i);
    }

    size = tproduct.size;
}

Product::~Product()
{
    list_products.erase(list_products.begin(), list_products.end());
    size = 0;
}

int Product::TotalVolume()
{
    int total_volume = 0;
    for(int i=0; i<size; i++)
    {
        Info tprod = list_products.front();
        list_products.pop_front();
        list_products.push_back(tprod);
        total_volume += tprod.prod_volume;
    }

    return total_volume;
}

int Product::ProdCost()
{
    int total_cost;
    /*int total_volume;
    total_volume = TotalVolume();
    for(int i=0; i<size; i++)
    {
        Info tprod = list_products.front();
        list_products.pop_front();
        list_products.push_back(tprod);
        total_cost = total_cost + tprod.material_cost + (salary + rent + other_costs)*(tprod.prod_volume/total_volume);
    }*/
    total_cost = salary + rent + other_costs;
    return total_cost;
}

void Product::Cost()
{
    int total_cost;
    total_cost = ProdCost();
    int total_volume;
    total_volume = TotalVolume();

    for(int i=0; i<size; i++)
    {
        Info tprod = list_products.front();
        list_products.pop_front();
        list_products.push_back(tprod);
        tprod.fin_cost = (tprod.material_cost + total_cost*(tprod.prod_volume/total_volume))/tprod.prod_volume;
    }
}

ostream& operator<< (ostream& out, Product& t)
{

}

istream& operator>> (istream& in, Product& t)
{

}
