/*Создание автоматизированной системы для расчета себестоимости оборудования

себестоимость = стоимость всех затрат : количество произведённого

*/

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string.h>
#pragma warning(disable:4996)
#include <string>
#include <list>
#include "func.h"
using namespace std;

int main()
{

}

/*
template <class T>
class Product
{
    list<T> list_products;
public:
    Product();
    Product(T tproduct);
    Product(list<T> tproduct);
    Product(Product& tproduct);
    ~Product();
    int ProdCost();
    int Cost();
    friend ostream& operator<< (ostream& out, Product& t);
    friend istream& operator>> (istream& in, Product& t);
};

template <class T>
Product::Product()
{

}

template <class T>
Product::Product(T tproduct)
{

}

template <class T>
Product::Product(list<T> tproduct)
{

}

template <class T>
Product::Product(Product& tproduct)
{

}

template <class T>
Product::~Product()
{

}

template <class T>
int Product::ProdCost()
{

}

template <class T>
int Product::Cost()
{

}
*/
