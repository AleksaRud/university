/*Создание автоматизированной системы для расчета себестоимости оборудования

себестоимость = стоимость всех затрат : количество произведённого

*/

#include <iostream>
#include <iomanip>
#include <fstream>
#include <string.h>
#pragma warning(disable:4996)
#include <string>
#include <list>
#include "func.h"
using namespace std;

int main()
{
    Product Prod;
    cin >> Prod;
    cout << setw(20) << "Menu" << endl;
    cout << endl;
    cout << "1. Generate random laptops" << endl;
    cout << "2. Choose parts from list" << endl;
    cout << "3. Exit" << endl;

    string choce;
    do
    {
        cout << "Choose 1, 2 or 3" << endl;
        cin >> choce;
    }
    while((choce != "1") && (choce != "2") && (choce != "3"));

    if(choce == "1")
    {
        Prod.ChooseBase(choce);
        Prod.ChooseVideocard(choce);
        Prod.ChooseStorageDevice(choce);
    }
    if(choce == "2")
    {
        Prod.ChooseBase(choce);
        Prod.ChooseVideocard(choce);
        Prod.ChooseStorageDevice(choce);
    }
    if(choce == "3")
    {
        return 0;
    }

}
