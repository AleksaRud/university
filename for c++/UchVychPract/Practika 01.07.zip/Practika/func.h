#define __LIST_H__
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string.h>
#pragma warning(disable:4996)
#include <string>
#include <list>
using namespace std;
struct Info
{
    string name_product;
    int material_cost;
    int prod_volume;
    int fin_cost;
};

class Product
{
    list<Info> laptop_base;
    int lbsize;
    list<Info> videocard;
    int vcsize;
    list<Info> storage_device;
    int sdsize;

    list<Info> list_products;
    int salary;
    int rent;
    int other_costs;
    int size;

public:
    Product();
    Product(Info tproduct);
    Product(list<Info> tproduct);
    Product(Product& tproduct);
    ~Product();
    void ChooseBase(string choce);
    void ChooseVideocard(string choce);
    void ChooseStorageDevice(string choce);
    void Add(Info tproduct);
    void Delete(int num);
    void Sort();
    int TotalVolume();
    int InderectCost();
    void ProdCost();

    friend istream& operator>> (istream& in, Product& t);
    void PrintResult();
};

Product::Product()
{
    size = 0;
    lbsize = 0;
    vcsize = 0;
    sdsize = 0;
}

Product::Product(Info tproduct)
{
    list_products.push_back(tproduct);
    size = 1;
}

Product::Product(list<Info> tproduct)
{
    for(auto i = tproduct.begin(); i!=tproduct.end(); i++)
    {
        list_products.push_back(*i);
        size++;
    }
}

Product::Product(Product& tproduct)
{
    for(auto i = tproduct.list_products.begin(); i!=tproduct.list_products.end(); i++)
    {
        list_products.push_back(*i);
    }

    size = tproduct.size;
}

Product::~Product()
{
    list_products.erase(list_products.begin(), list_products.end());
    size = 0;
}

void Product::ChooseBase(string choce)
{
    int num;
    if(choce == "2")
    {
        cout << setw(85) << setfill('=') << "=" << setfill(' ') <<endl;
        cout << setw(5) << "|" << setw(20) << "Name of product" << setw(5) << "|" << setw(20) << "Cost of materials" << setw(5) << "|";
        cout << setw(20) << "Production volume" << setw(5) << "|" << endl;
        cout << setw(85) << setfill('=') << "=" << setfill(' ') <<endl;
        for(int i=0; i<lbsize; i++)
        {
            Info tinfo = laptop_base.front();
            laptop_base.pop_front();
            cout << i+1 << ". " << setw(2) << "|" << setw(20) << tinfo.name_product << setw(5) << "|" << setw(20) << tinfo.material_cost << setw(5) << "|";
            cout << setw(20) << tinfo.prod_volume << setw(5) << "|" << endl;
            laptop_base.push_back(tinfo);
        }
        cout << lbsize+1 << ". Random" <<endl;

        do
        {
            cout << "Choose current laptop base or random" << endl;
            cin >> num;
        }
        while((num > (lbsize+1)) || (num < 0) );

        cout << endl;
        if(num == lbsize+1)
            num = rand()%lbsize + 1;
    }
    if(choce == "1")
    {
        num = rand()%lbsize + 1;
    }

    Info temp;
    int j = 0;
    for(auto i = laptop_base.begin(); i != laptop_base.end(); i++)
    {
        if(j<num)
        {
            temp = *i;
            j++;
        }
        else
            break;
    }
    if(choce == "2")
        cout << temp.name_product << setw(10) << temp.material_cost << setw(10) << temp.prod_volume << endl;
    list_products.push_back(temp);
}

void Product::ChooseVideocard(string choce)
{
    int num;
    if(choce == "2")
    {
        cout << setw(85) << setfill('=') << "=" << setfill(' ') <<endl;
        cout << setw(5) << "|" << setw(20) << "Name of product" << setw(5) << "|" << setw(20) << "Cost of materials" << setw(5) << "|";
        cout << setw(20) << "Production volume" << setw(5) << "|" << endl;
        cout << setw(85) << setfill('=') << "=" << setfill(' ') <<endl;
        for(int i=0; i<vcsize; i++)
        {
            Info tinfo = videocard.front();
            videocard.pop_front();
            cout << i+1 << ". " << setw(2) << "|" << setw(20) << tinfo.name_product << setw(5) << "|" << setw(20) << tinfo.material_cost << setw(5) << "|";
            cout << setw(20) << tinfo.prod_volume << setw(5) << "|" << endl;
            videocard.push_back(tinfo);
        }
        cout << vcsize+1 << ". Random" <<endl;

        do
        {
            cout << "Choose current videocard or random" << endl;
            cin >> num;
        }
        while((num > (vcsize+1)) || (num < 0) );

        cout << endl;

        if(num == vcsize+1)
            num = rand()%vcsize + 1;
    }
    if(choce == "1")
    {
        num = rand()%vcsize + 1;
    }

    Info temp = list_products.back();
    list_products.pop_back();
    Info temp1;

    int j = 0;
    for(auto i = videocard.begin() ; i != videocard.end(); i++)
    {
        if(j<num)
        {
            temp1 = *i;
            j++;
        }
        else
            break;

    }

    temp.name_product = temp.name_product + "; " + temp1.name_product;
    temp.material_cost = temp.material_cost + temp1.material_cost;
    if(temp.prod_volume > temp1.prod_volume)
        temp.prod_volume = temp1.prod_volume;
    else
        temp.prod_volume = temp.prod_volume;

    if(choce == "2")
        cout << temp.name_product << setw(10) << temp.material_cost << setw(10) << temp.prod_volume << endl;
    list_products.push_back(temp);
}

void Product::ChooseStorageDevice(string choce)
{
    int num;
    if(choce == "2")
    {
        cout << setw(85) << setfill('=') << "=" << setfill(' ') <<endl;
        cout << setw(5) << "|" << setw(20) << "Name of product" << setw(5) << "|" << setw(20) << "Cost of materials" << setw(5) << "|";
        cout << setw(20) << "Production volume" << setw(5) << "|" << endl;
        cout << setw(85) << setfill('=') << "=" << setfill(' ') <<endl;
        for(int i=0; i<sdsize; i++)
        {
            Info tinfo = storage_device.front();
            storage_device.pop_front();
            cout << i+1 << ". " << setw(2) << "|" << setw(20) << tinfo.name_product << setw(5) << "|" << setw(20) << tinfo.material_cost << setw(5) << "|";
            cout << setw(20) << tinfo.prod_volume << setw(5) << "|" << endl;
            storage_device.push_back(tinfo);
        }
        cout << sdsize+1 << ". Random" <<endl;

        do
        {
            cout << "Choose current videocard or random" << endl;
            cin >> num;
        }
        while((num > (sdsize+1)) || (num < 0) );

        cout << endl;

        if(num == sdsize+1)
            num = rand()%sdsize + 1;
    }

    if(choce == "1")
    {
        num = rand()%sdsize + 1;
    }

    Info temp = list_products.back();
    list_products.pop_back();
    Info temp1;
    int j = 0;
    for(auto i = storage_device.begin(); i != storage_device.end(); i++)
    {
        if(j<num)
        {
            temp1 = *i;
            j++;
        }
        else
            break;
    }
    temp.name_product = temp.name_product + "; " + temp1.name_product;
    temp.material_cost = temp.material_cost + temp1.material_cost;
    if(temp.prod_volume > temp1.prod_volume)
        temp.prod_volume = temp1.prod_volume;
    else
        temp.prod_volume = temp.prod_volume;

    cout << temp.name_product << setw(10) << temp.material_cost << setw(10) << temp.prod_volume << endl;
    list_products.push_back(temp);
}

void Product::Add(Info tproduct)
{
    list_products.push_back(tproduct);
    size++;
}

void Product::Delete(int num)
{
    auto i = list_products.begin();
    for(int j = 0; j<num; j++)
        i++;
    list_products.erase(i);
}

void Product::Sort()
{

}

int Product::TotalVolume()
{
    int total_volume = 0;
    for(int i=0; i<size; i++)
    {
        Info tprod = list_products.front();
        list_products.pop_front();
        total_volume += tprod.prod_volume;
        list_products.push_back(tprod);
    }

    return total_volume;
}

int Product::InderectCost()
{
    int total_cost;
    total_cost = salary + rent + other_costs;
    return total_cost;
}

void Product::ProdCost()
{
    int inderect_cost;
    inderect_cost = InderectCost();
    int total_volume;
    total_volume = TotalVolume();

    cout<< setw(20) << "Total production volume:" << setw(6) << total_volume<<endl;
    for(int i=0; i<size; i++)
    {
        Info tprod = list_products.front();
        list_products.pop_front();

        double proc = double(tprod.prod_volume)/double(total_volume);
        tprod.fin_cost = (tprod.material_cost + inderect_cost*proc)/tprod.prod_volume;

        list_products.push_back(tprod);
    }
}

istream& operator>> (istream& in, Product& t)
{
    string str[30], space = " ";
    ifstream in1("Input_Info.txt");
    if (in1.is_open())
    {
        while (getline(in1, str[t.size]))
        {
            t.size++;
        }

    }
    in1.close();

    t.salary = stoi(str[0]);
    t.rent = stoi(str[1]);
    t.other_costs = stoi(str[2]);

    Info tinfo;

    string tname;
    string tcost;
    string tvolume;

    for(int i=3; i<t.size; i++)
    {

        tname.assign(str[i], 1, str[i].find_first_of(",")-1);
        tcost.assign(str[i], str[i].find_first_of(",")+1, str[i].find_last_of(",")-str[i].find_first_of(",")-1);
        tvolume.assign(str[i], str[i].find_last_of(",")+1, str[i].size() - str[i].find_last_of(","));

        tinfo.name_product = tname;
        tinfo.material_cost = stoi(tcost);
        tinfo.prod_volume = stoi(tvolume);

        if(str[i][0]=='!')
        {
            t.laptop_base.push_back(tinfo);
            t.lbsize++;
        }
        if(str[i][0]=='?')
        {
            t.videocard.push_back(tinfo);
            t.vcsize++;
        }
        if(str[i][0]=='%')
        {
            t.storage_device.push_back(tinfo);
            t.sdsize++;
        }
        //t.list_products.push_back(tinfo);

        tinfo.name_product.clear();
        tname.clear();
        tcost.clear();
        tvolume.clear();
    }
    //t.size-=3;

    /*
    cout << "|" << setw(30) << "Name of product" << setw(5) << "|" << setw(20) << "Cost of materials" << setw(5) << "|";
    cout << setw(20) << "Production volume" << setw(5) << "|" << endl;
    cout << setw(85) << setfill('=') << "=" << setfill(' ') <<endl;
    for(int i=0; i<t.lbsize; i++)
    {
        Info tinfo = t.laptop_base.front();
        t.laptop_base.pop_front();
        cout << "|" << setw(30) << tinfo.name_product << setw(5) << "|" << setw(20) << tinfo.material_cost << setw(5) << "|";
        cout << setw(20) << tinfo.prod_volume << setw(5) << "|" << endl;
        t.laptop_base.push_back(tinfo);
    }
    for(int i=0; i<t.vcsize; i++)
    {
        Info tinfo = t.videocard.front();
        t.videocard.pop_front();
        cout << "|" << setw(30) << tinfo.name_product << setw(5) << "|" << setw(20) << tinfo.material_cost << setw(5) << "|";
        cout << setw(20) << tinfo.prod_volume << setw(5) << "|" << endl;
        t.videocard.push_back(tinfo);
    }
    for(int i=0; i<t.sdsize; i++)
    {
        Info tinfo = t.storage_device.front();
        t.storage_device.pop_front();
        cout << "|" << setw(30) << tinfo.name_product << setw(5) << "|" << setw(20) << tinfo.material_cost << setw(5) << "|";
        cout << setw(20) << tinfo.prod_volume << setw(5) << "|" << endl;
        t.storage_device.push_back(tinfo);
    }
    /*for(int i=0; i<t.size; i++)
    {
        //Info tinfo = t.list_products.front();
        //t.list_products.pop_front();
        cout << "|" << setw(30) << tinfo.name_product << setw(5) << "|" << setw(20) << tinfo.material_cost << setw(5) << "|";
        cout << setw(20) << tinfo.prod_volume << setw(5) << "|" << endl;
        //t.list_products.push_back(tinfo);
    }
    cout << endl;
    cout << setw(14) << "Salary:" << setw(10) << t.salary <<endl;
    cout << setw(14) << "Cost of rent:" << setw(10) << t.rent <<endl;
    cout << setw(14) << "Other costs:" << setw(10) << t.other_costs <<endl;
    */

    return in;
}

void Product::PrintResult()
{
    string for_output;
    cout << "|" << setw(30) << "Name of product" << setw(5) << "|" << setw(20) << "Cost of materials" << setw(5) << "|";
    cout << setw(20) << "Production volume" << setw(5) << "|" << setw(20) << "Final cost of 1 product" << setw(2) << "|" << endl;
    cout << setw(110) << setfill('=') << "=" << setfill(' ') <<endl;
    for(int i=0; i<size; i++)
    {
        Info tinfo = list_products.front();
        list_products.pop_front();
        cout << "|" << setw(30) << tinfo.name_product << setw(5) << "|" << setw(20) << tinfo.material_cost << setw(5) << "|";
        cout << setw(20) << tinfo.prod_volume << setw(5) << "|" << setw(20) << tinfo.fin_cost << setw(5) << "|" << endl;
        for_output = for_output + tinfo.name_product + ": " + to_string(tinfo.material_cost) + "   " + to_string(tinfo.prod_volume) + "   " + to_string(tinfo.fin_cost) + '\n';
        list_products.push_back(tinfo);
    }

    ofstream out;
    out.open("Result.txt");
    out << for_output << endl;
    out.close();
}
