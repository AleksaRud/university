#include "ChoiceDialog.h"

//(*InternalHeaders(ChoiceDialog)
#include <wx/intl.h>
#include <wx/string.h>
//*)

//(*IdInit(ChoiceDialog)
const long ChoiceDialog::ID_STATICTEXT1 = wxNewId();
const long ChoiceDialog::ID_BUTTON1 = wxNewId();
const long ChoiceDialog::ID_PANEL1 = wxNewId();
//*)

BEGIN_EVENT_TABLE(ChoiceDialog,wxDialog)
	//(*EventTable(ChoiceDialog)
	//*)
END_EVENT_TABLE()

ChoiceDialog::ChoiceDialog(wxWindow* parent,wxWindowID id)
{
	//(*Initialize(ChoiceDialog)
	Create(parent, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxDEFAULT_DIALOG_STYLE, _T("wxID_ANY"));
	SetClientSize(wxSize(383,300));
	Panel1 = new wxPanel(this, ID_PANEL1, wxPoint(0,0), wxSize(384,304), wxTAB_TRAVERSAL, _T("ID_PANEL1"));
	StaticText1 = new wxStaticText(Panel1, ID_STATICTEXT1, _("Choose from lists"), wxPoint(136,24), wxDefaultSize, 0, _T("ID_STATICTEXT1"));
	Button1 = new wxButton(Panel1, ID_BUTTON1, _("Okey"), wxPoint(216,64), wxDefaultSize, 0, wxDefaultValidator, _T("ID_BUTTON1"));

	Connect(ID_BUTTON1,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&ChoiceDialog::OnButton1Click);
	//*)
}

ChoiceDialog::~ChoiceDialog()
{
	//(*Destroy(ChoiceDialog)
	//*)
}


void ChoiceDialog::OnButton1Click(wxCommandEvent& event)
{
    Close();
}
