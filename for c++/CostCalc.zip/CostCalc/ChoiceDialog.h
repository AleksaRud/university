#ifndef CHOICEDIALOG_H
#define CHOICEDIALOG_H

//(*Headers(ChoiceDialog)
#include <wx/button.h>
#include <wx/dialog.h>
#include <wx/panel.h>
#include <wx/stattext.h>
//*)

class ChoiceDialog: public wxDialog
{
	public:

		ChoiceDialog(wxWindow* parent,wxWindowID id=wxID_ANY);
		virtual ~ChoiceDialog();

		//(*Declarations(ChoiceDialog)
		wxButton* Button1;
		wxPanel* Panel1;
		wxStaticText* StaticText1;
		//*)

	protected:

		//(*Identifiers(ChoiceDialog)
		static const long ID_STATICTEXT1;
		static const long ID_BUTTON1;
		static const long ID_PANEL1;
		//*)

	private:

		//(*Handlers(ChoiceDialog)
		void OnButton1Click(wxCommandEvent& event);
		//*)

		DECLARE_EVENT_TABLE()
};

#endif
