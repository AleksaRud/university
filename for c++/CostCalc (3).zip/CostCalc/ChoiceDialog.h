#ifndef CHOICEDIALOG_H
#define CHOICEDIALOG_H

//(*Headers(ChoiceDialog)
#include <wx/button.h>
#include <wx/choice.h>
#include <wx/dialog.h>
#include <wx/statbox.h>
#include <wx/stattext.h>
//*)

class ChoiceDialog: public wxDialog
{
	public:

		ChoiceDialog(wxWindow* parent,wxWindowID id=wxID_ANY);
		virtual ~ChoiceDialog();

		//(*Declarations(ChoiceDialog)
		wxButton* Button1;
		wxButton* Button2;
		wxChoice* Choice1;
		wxChoice* Choice2;
		wxChoice* Choice3;
		wxStaticBox* StaticBox1;
		wxStaticBox* StaticBox2;
		wxStaticBox* StaticBox3;
		wxStaticText* StaticText1;
		//*)

	protected:

		//(*Identifiers(ChoiceDialog)
		static const long ID_BUTTON1;
		static const long ID_STATICBOX1;
		static const long ID_STATICTEXT1;
		static const long ID_STATICBOX2;
		static const long ID_STATICBOX3;
		static const long ID_CHOICE1;
		static const long ID_CHOICE2;
		static const long ID_CHOICE3;
		static const long ID_BUTTON2;
		//*)

	private:

		//(*Handlers(ChoiceDialog)
		void OnButton1Click(wxCommandEvent& event);
		void OnButton2Click(wxCommandEvent& event);
		void OnChoice1Select(wxCommandEvent& event);
		void OnChoice2Select(wxCommandEvent& event);
		void OnChoice3Select(wxCommandEvent& event);
		//*)

		DECLARE_EVENT_TABLE()
};

#endif
