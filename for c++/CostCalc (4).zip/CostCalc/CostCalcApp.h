/***************************************************************
 * Name:      CostCalcApp.h
 * Purpose:   Defines Application Class
 * Author:     ()
 * Created:   2023-10-27
 * Copyright:  ()
 * License:
 **************************************************************/

#ifndef COSTCALCAPP_H
#define COSTCALCAPP_H

#include <wx/app.h>

class CostCalcApp : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // COSTCALCAPP_H
