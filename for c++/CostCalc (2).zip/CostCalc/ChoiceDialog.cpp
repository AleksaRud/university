#include "ChoiceDialog.h"
#include <wx/msgdlg.h>
#include "CalcFunc.h"
//(*InternalHeaders(ChoiceDialog)
#include <wx/intl.h>
#include <wx/string.h>
//*)

//(*IdInit(ChoiceDialog)
const long ChoiceDialog::ID_BUTTON1 = wxNewId();
const long ChoiceDialog::ID_STATICBOX1 = wxNewId();
const long ChoiceDialog::ID_STATICTEXT1 = wxNewId();
const long ChoiceDialog::ID_STATICBOX2 = wxNewId();
const long ChoiceDialog::ID_STATICBOX3 = wxNewId();
const long ChoiceDialog::ID_CHOICE1 = wxNewId();
const long ChoiceDialog::ID_CHOICE2 = wxNewId();
const long ChoiceDialog::ID_CHOICE3 = wxNewId();
const long ChoiceDialog::ID_BUTTON2 = wxNewId();
//*)

BEGIN_EVENT_TABLE(ChoiceDialog,wxDialog)
	//(*EventTable(ChoiceDialog)
	//*)
END_EVENT_TABLE()

ChoiceDialog::ChoiceDialog(wxWindow* parent,wxWindowID id)
{
	//(*Initialize(ChoiceDialog)
	Create(parent, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxDEFAULT_DIALOG_STYLE, _T("wxID_ANY"));
	SetClientSize(wxSize(337,282));
	Button1 = new wxButton(this, ID_BUTTON1, _("Okey"), wxPoint(208,224), wxDefaultSize, 0, wxDefaultValidator, _T("ID_BUTTON1"));
	StaticBox1 = new wxStaticBox(this, ID_STATICBOX1, _("Micro processor"), wxPoint(8,32), wxSize(320,56), 0, _T("ID_STATICBOX1"));
	StaticText1 = new wxStaticText(this, ID_STATICTEXT1, _("Choose from lists"), wxPoint(112,8), wxDefaultSize, 0, _T("ID_STATICTEXT1"));
	StaticBox2 = new wxStaticBox(this, ID_STATICBOX2, _("Videocard"), wxPoint(8,88), wxSize(320,56), 0, _T("ID_STATICBOX2"));
	StaticBox3 = new wxStaticBox(this, ID_STATICBOX3, _("Storage device"), wxPoint(8,144), wxSize(320,56), 0, _T("ID_STATICBOX3"));
	Choice1 = new wxChoice(this, ID_CHOICE1, wxPoint(16,56), wxSize(304,28), 0, 0, 0, wxDefaultValidator, _T("ID_CHOICE1"));
	Choice1->Append(_("Intel Core i3"));
	Choice1->Append(_("Intel Core i5"));
	Choice1->Append(_("Intel Core i7"));
	Choice2 = new wxChoice(this, ID_CHOICE2, wxPoint(16,112), wxSize(304,28), 0, 0, 0, wxDefaultValidator, _T("ID_CHOICE2"));
	Choice3 = new wxChoice(this, ID_CHOICE3, wxPoint(16,168), wxSize(304,28), 0, 0, 0, wxDefaultValidator, _T("ID_CHOICE3"));
	Button2 = new wxButton(this, ID_BUTTON2, _("Cancel"), wxPoint(32,224), wxDefaultSize, 0, wxDefaultValidator, _T("ID_BUTTON2"));

	Connect(ID_BUTTON1,wxEVT_COMMAND_BUTTON_CLICKED,(wxObjectEventFunction)&ChoiceDialog::OnButton1Click);
	Connect(ID_CHOICE1,wxEVT_COMMAND_CHOICE_SELECTED,(wxObjectEventFunction)&ChoiceDialog::OnChoice1Select);
	Connect(ID_CHOICE2,wxEVT_COMMAND_CHOICE_SELECTED,(wxObjectEventFunction)&ChoiceDialog::OnChoice2Select);
	//*)
}

ChoiceDialog::~ChoiceDialog()
{
	//(*Destroy(ChoiceDialog)
	//*)
}


void ChoiceDialog::OnButton1Click(wxCommandEvent& event)
{
    Close();
}

void ChoiceDialog::OnChoice2Select(wxCommandEvent& event)
{
}

void ChoiceDialog::OnChoice1Select(wxCommandEvent& event)
{
    int i = Choice1->GetSelection();
    if (i==0)
    {
        wxString msg = "case 0";
        wxMessageBox(msg, _("New list"));
    }
    if (i==1)
    {
        wxString msg = "case 1";
        wxMessageBox(msg, _("New list"));
    }
    if (i==2)
    {
        wxString msg = "case 2";
        wxMessageBox(msg, _("New list"));
    }
}
