/***************************************************************
 * Name:      CostCalcMain.cpp
 * Purpose:   Code for Application Frame
 * Author:     ()
 * Created:   2023-10-27
 * Copyright:  ()
 * License:
 **************************************************************/

#include "CostCalcMain.h"
#include <wx/msgdlg.h>
#include <wx/grid.h>
#include "ChoiceDialog.h"
#include "CalcFunc.h"
//(*InternalHeaders(CostCalcFrame)
#include <wx/intl.h>
#include <wx/string.h>
//*)

//helper functions
enum wxbuildinfoformat {
    short_f, long_f };

wxString wxbuildinfo(wxbuildinfoformat format)
{
    wxString wxbuild(wxVERSION_STRING);

    if (format == long_f )
    {
#if defined(__WXMSW__)
        wxbuild << _T("-Windows");
#elif defined(__UNIX__)
        wxbuild << _T("-Linux");
#endif

#if wxUSE_UNICODE
        wxbuild << _T("-Unicode build");
#else
        wxbuild << _T("-ANSI build");
#endif // wxUSE_UNICODE
    }

    return wxbuild;
}

//(*IdInit(CostCalcFrame)
const long CostCalcFrame::ID_PANEL1 = wxNewId();
const long CostCalcFrame::idMenuNewList = wxNewId();
const long CostCalcFrame::idMenuSave = wxNewId();
const long CostCalcFrame::idMenuQuit = wxNewId();
const long CostCalcFrame::idAddChoose = wxNewId();
const long CostCalcFrame::idAddKeyboard = wxNewId();
const long CostCalcFrame::ID_MENUITEM1 = wxNewId();
const long CostCalcFrame::idEditDelete = wxNewId();
const long CostCalcFrame::idEditSort = wxNewId();
const long CostCalcFrame::idMenuAbout = wxNewId();
const long CostCalcFrame::ID_STATUSBAR1 = wxNewId();
//*)

BEGIN_EVENT_TABLE(CostCalcFrame,wxFrame)
    //(*EventTable(CostCalcFrame)
    //*)
END_EVENT_TABLE()

CostCalcFrame::CostCalcFrame(wxWindow* parent,wxWindowID id)
{
    //(*Initialize(CostCalcFrame)
    wxMenu* Menu1;
    wxMenu* Menu2;
    wxMenuBar* MenuBar1;
    wxMenuItem* MenuItem1;
    wxMenuItem* MenuItem2;

    Create(parent, wxID_ANY, wxEmptyString, wxDefaultPosition, wxDefaultSize, wxDEFAULT_FRAME_STYLE, _T("wxID_ANY"));
    Panel1 = new wxPanel(this, ID_PANEL1, wxPoint(32,72), wxDefaultSize, wxTAB_TRAVERSAL, _T("ID_PANEL1"));
    MenuBar1 = new wxMenuBar();
    Menu1 = new wxMenu();
    MenuItem3 = new wxMenuItem(Menu1, idMenuNewList, _("New list"), _("Create new list"), wxITEM_NORMAL);
    Menu1->Append(MenuItem3);
    MenuItem4 = new wxMenuItem(Menu1, idMenuSave, _("Save"), _("Save list"), wxITEM_NORMAL);
    Menu1->Append(MenuItem4);
    MenuItem1 = new wxMenuItem(Menu1, idMenuQuit, _("Quit\tAlt-F4"), _("Quit the application"), wxITEM_NORMAL);
    Menu1->Append(MenuItem1);
    MenuBar1->Append(Menu1, _("&File"));
    Menu3 = new wxMenu();
    MenuItem5 = new wxMenu();
    MenuItem6 = new wxMenuItem(MenuItem5, idAddChoose, _("Choose elements"), wxEmptyString, wxITEM_NORMAL);
    MenuItem5->Append(MenuItem6);
    MenuItem7 = new wxMenuItem(MenuItem5, idAddKeyboard, _("Keyboard input"), wxEmptyString, wxITEM_NORMAL);
    MenuItem5->Append(MenuItem7);
    Menu3->Append(ID_MENUITEM1, _("Add"), MenuItem5, wxEmptyString);
    MenuItem8 = new wxMenuItem(Menu3, idEditDelete, _("Delete"), wxEmptyString, wxITEM_NORMAL);
    Menu3->Append(MenuItem8);
    MenuItem9 = new wxMenuItem(Menu3, idEditSort, _("Sort"), wxEmptyString, wxITEM_NORMAL);
    Menu3->Append(MenuItem9);
    MenuBar1->Append(Menu3, _("Edit"));
    Menu2 = new wxMenu();
    MenuItem2 = new wxMenuItem(Menu2, idMenuAbout, _("About\tF1"), _("Show info about this application"), wxITEM_NORMAL);
    Menu2->Append(MenuItem2);
    MenuBar1->Append(Menu2, _("Help"));
    SetMenuBar(MenuBar1);
    StatusBar1 = new wxStatusBar(this, ID_STATUSBAR1, 0, _T("ID_STATUSBAR1"));
    int __wxStatusBarWidths_1[1] = { -1 };
    int __wxStatusBarStyles_1[1] = { wxSB_NORMAL };
    StatusBar1->SetFieldsCount(1,__wxStatusBarWidths_1);
    StatusBar1->SetStatusStyles(1,__wxStatusBarStyles_1);
    SetStatusBar(StatusBar1);

    Connect(idMenuQuit,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&CostCalcFrame::OnQuit);
    Connect(idMenuAbout,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&CostCalcFrame::OnAbout);
    //*)
    Connect(idMenuNewList,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&CostCalcFrame::OnNewList);
    Connect(idMenuSave,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&CostCalcFrame::OnSave);
    Connect(idEditSort,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&CostCalcFrame::OnSort);
    Connect(idEditDelete,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&CostCalcFrame::OnDelete);
    Connect(idAddChoose,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&CostCalcFrame::OnChoce);
    Connect(idAddKeyboard,wxEVT_COMMAND_MENU_SELECTED,(wxObjectEventFunction)&CostCalcFrame::OnKeyboard);
}

CostCalcFrame::~CostCalcFrame()
{
    //(*Destroy(CostCalcFrame)
    //*)
}

void CostCalcFrame::OnQuit(wxCommandEvent& event)
{
    Close();
}

void CostCalcFrame::OnAbout(wxCommandEvent& event)
{
    wxString msg = wxbuildinfo(long_f);
    wxMessageBox(msg, _("Welcome to..."));
}

void CostCalcFrame::OnNewList(wxCommandEvent& event)
{
    //wxString msg = "created";
    //wxMessageBox(msg, _("New list"));
    wxGrid* grid;
    grid = new wxGrid(this, -1, wxPoint(0,0), wxSize(400, 300));
    grid->CreateGrid(2, 4);
    grid->SetCellValue( 0, 0, "wxGrid is good" );
    //grid->SetRowSize(0, 60);
    //grid->SetColSize(0, 60);
}

void CostCalcFrame::OnSave(wxCommandEvent& event)
{
    wxString msg = "saved";
    wxMessageBox(msg, _("New list"));
}

void CostCalcFrame::OnSort(wxCommandEvent& event)
{
    wxString msg = "sorted";
    wxMessageBox(msg, _("New list"));
}

void CostCalcFrame::OnDelete(wxCommandEvent& event)
{
    wxString msg = "deleted";
    wxMessageBox(msg, _("New list"));
}

void CostCalcFrame::OnChoce(wxCommandEvent& event)
{
    ChoiceDialog dialog(this);
    dialog.ShowModal();
    //wxString msg = "your choce";
    //wxMessageBox(msg, _("New list"));
}

void CostCalcFrame::OnKeyboard(wxCommandEvent& event)
{
    wxString msg = "keyboard input";
    wxMessageBox(msg, _("New list"));
}



void CostCalcFrame::OnChoice1Select1(wxCommandEvent& event)
{
}
